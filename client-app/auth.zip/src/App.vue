<template>
  <VApp>
    <RouterView />
  </VApp>
</template>
